//
//  ___FILENAME___
//  ___PROJECTNAME___
//  Module: ___VARIABLE_viperModuleName___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___ViewPresenterProtocol: ViewPresenterProtocol {
}

protocol ___FILEBASENAMEASIDENTIFIER___InteractorPresenterProtocol: class {
}

final class ___FILEBASENAMEASIDENTIFIER___Presenter {
    
    // MARK: Constants
    let router: ___FILEBASENAMEASIDENTIFIER___PresenterRouterProtocol
    let interactor: ___FILEBASENAMEASIDENTIFIER___PresenterInteractorProtocol
    
    // MARK: Variables
    weak var view: ___FILEBASENAMEASIDENTIFIER___PresenterViewProtocol?
    
    // MARK: Inits
    init(router: ___FILEBASENAMEASIDENTIFIER___PresenterRouterProtocol, interactor: ___FILEBASENAMEASIDENTIFIER___PresenterInteractorProtocol) {
        self.router = router
        self.interactor = interactor
    }
}

// MARK: ___FILEBASENAMEASIDENTIFIER___ view to present protocol
extension ___FILEBASENAMEASIDENTIFIER___Presenter: ___FILEBASENAMEASIDENTIFIER___ViewPresenterProtocol {
    
    func viewLoaded() {
    }
}

// MARK: ___FILEBASENAMEASIDENTIFIER___ interactor to present protocol
extension ___FILEBASENAMEASIDENTIFIER___Presenter: ___FILEBASENAMEASIDENTIFIER___InteractorPresenterProtocol {
}
