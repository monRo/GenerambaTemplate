//
//  ___FILENAME___
//  ___PROJECTNAME___
//  Module: ___VARIABLE_viperModuleName___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation

protocol ___FILEBASENAMEASIDENTIFIER___PresenterInteractorProtocol {
}

final class ___FILEBASENAMEASIDENTIFIER___Interactor {
    
    // MARK: Variables
    weak var presenter: ___FILEBASENAMEASIDENTIFIER___InteractorPresenterProtocol?
}

// MARK: ___FILEBASENAMEASIDENTIFIER___ presenter to interactor protocol
extension ___FILEBASENAMEASIDENTIFIER___Interactor: ___FILEBASENAMEASIDENTIFIER___PresenterInteractorProtocol {
}
