//
//  ___FILENAME___
//  ___PROJECTNAME___
//  Module: ___VARIABLE_viperModuleName___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

// MARK: Imports

import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___PresenterViewProtocol: class {
}

class ___FILEBASENAMEASIDENTIFIER___ViewController: UIViewController {
    
    // MARK: Constants
    let presenter: ___FILEBASENAMEASIDENTIFIER___ViewPresenterProtocol
    
    // MARK: Inits
    init(presenter: ___FILEBASENAMEASIDENTIFIER___ViewPresenterProtocol) {
        self.presenter = presenter
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: View lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

// MARK: ___FILEBASENAMEASIDENTIFIER___ presenter to view protocol
extension ___FILEBASENAMEASIDENTIFIER___ViewController: ___FILEBASENAMEASIDENTIFIER___PresenterViewProtocol {
}
