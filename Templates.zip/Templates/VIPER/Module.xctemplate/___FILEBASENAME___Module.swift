//
//  ___FILENAME___
//  ___PROJECTNAME___
//  Module: ___VARIABLE_viperModuleName___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit

final class ___FILEBASENAMEASIDENTIFIER___Module {
    
    // MARK: Variables
    private(set) lazy var interactor: ___FILEBASENAMEASIDENTIFIER___Interactor = {
        return ___FILEBASENAMEASIDENTIFIER___Interactor()
    }()
    
    private(set) lazy var router: ___FILEBASENAMEASIDENTIFIER___Router = {
        return ___FILEBASENAMEASIDENTIFIER___Router()
    }()
    
    private(set) lazy var presenter: ___FILEBASENAMEASIDENTIFIER___Presenter = {
        return ___FILEBASENAMEASIDENTIFIER___Presenter(router: self.router, interactor: self.interactor)
    }()
    
    private(set) lazy var view: ___FILEBASENAMEASIDENTIFIER___ViewController = {
        let viewController = ___FILEBASENAMEASIDENTIFIER___ViewController(presenter: self.presenter)
        return viewController
    }()
    
    init() {
        presenter.view = view
        router.viewController = view
        interactor.presenter = presenter
    }
}

// MARK: Module protocol
extension ___FILEBASENAMEASIDENTIFIER___Module: ModuleProtocol {
    
    var viewController: UIViewController {
        return view
    }
}
