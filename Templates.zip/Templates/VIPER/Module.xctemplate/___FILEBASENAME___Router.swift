//
//  ___FILENAME___
//  ___PROJECTNAME___
//  Module: ___VARIABLE_viperModuleName___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___PresenterRouterProtocol {
}

final class ___FILEBASENAMEASIDENTIFIER___Router {
    
    // MARK: Variables
    weak var viewController: UIViewController?
}

// MARK: ___FILEBASENAMEASIDENTIFIER___ presenter to router protocol
extension ___FILEBASENAMEASIDENTIFIER___Router: ___FILEBASENAMEASIDENTIFIER___PresenterRouterProtocol {
}

// MARK: Router protocol
extension ___FILEBASENAMEASIDENTIFIER___Router: RouterProtocol {
}
